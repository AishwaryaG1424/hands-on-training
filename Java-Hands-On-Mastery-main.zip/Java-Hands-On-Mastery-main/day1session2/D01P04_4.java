package com.learning.core.day1session2;

public class D01P04_4 {
	
	public static void main (String [] args ) {
		
		
	}

}
